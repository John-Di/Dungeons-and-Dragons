#pragma once

#include <iostream>
#include "CharacterClasses.h"

 


	int CharacterClasses::Character::checkLevelUp(int exp) 		//Checks to see if a character's exp passed the level up threshold
	{			
		int currentExp = this -> exp,
			level = this -> level, 
			nextLevelEXP;

		if(currentExp >= (nextLevelEXP = (level * (level + 1) * 500)))
		{				
			levelUp();

			return checkLevelUp(currentExp - nextLevelEXP);
		}

		return currentExp;
	}
	void CharacterClasses::Character::levelUp()
		{
			this -> level++;
		}		
	
	CharacterClasses::Character::Character(string name) : name(name){exp = 0;};

	int CharacterClasses::Character::getHP()
		{
			return hp;
		}
	int CharacterClasses::Character::getLevel()
		{
			return level;
		}
	int CharacterClasses::Character::getStrength()
		{
			return str;
		}
	int CharacterClasses::Character::getDexterity()
		{
			return dex;
		}
	int CharacterClasses::Character::getConstitution()
		{
			return con;
		}
	int CharacterClasses::Character::getIntelligence()
		{
			return intl;
		}
	int CharacterClasses::Character::getWisdom()
		{
			return wis;
		}
	int CharacterClasses::Character::getCharisma()
		{
			return cha;
		}
	int CharacterClasses::Character::getExperience()
		{
			return exp;
		}
	string CharacterClasses::Character::getName()
		{
			return this -> name;
		}
	
	void CharacterClasses::Character::setHP(int hp)
		{
			this -> hp = hp;
		}
	void CharacterClasses::Character::setLevel(int level)
		{
			this -> level = level;
		}
	void CharacterClasses::Character::setStrength(int str)
		{
			this -> str = str;
		}
	void CharacterClasses::Character::setDexterity(int dex)
		{
			this -> dex = dex;
		}
	void CharacterClasses::Character::setConstitution(int con)
		{
			this -> con = con;
		}
	void CharacterClasses::Character::setIntelligence(int intl)
		{
			this -> intl = intl;
		}
	void CharacterClasses::Character::setWisdom(int wis)
		{
			this -> wis = wis;
		}
	void CharacterClasses::Character::setCharisma(int cha)
		{
			this -> cha = cha;
		}
	void CharacterClasses::Character::gainExperience(int exp)					//After spending exp to level up (if level up is possible with amount of exp), 
		{														//the remaining amount of exp becomes the new value
			this -> exp = checkLevelUp(exp);			
		}
	void CharacterClasses::Character::setName(string name)
		{
			this -> name = name;
		}

	Helmet CharacterClasses::Character::getHelmet()
		{
			return helmet;
		}
	Ring   CharacterClasses::Character::getRing1()
		{
			return ring1;
		}
	Ring   CharacterClasses::Character::getRing2()
		{
			return ring2;
		}
	Weapon CharacterClasses::Character::getWeapon()
		{
			return weapon;
		}
	Shield CharacterClasses::Character::getShield()
		{
			return shield;
		}
	Armor  CharacterClasses::Character::getArmor()
		{
			return armor;
		}
	Belt   CharacterClasses::Character::getBelt()
		{
			return belt;
		}
	Boots  CharacterClasses::Character::getBoots()
		{
			return boots;
		}

	void CharacterClasses::Character::equipHelmet(Helmet helmet)
		{
			this -> helmet = helmet;

			updateStats(helmet.getStrength(), helmet.getDexterity(), helmet.getConstitution(), helmet.getIntelligence(), helmet.getWisdom(), helmet.getCharisma());
		}
	void CharacterClasses::Character::equipRing1(Ring ring)
		{
			this -> ring1 = ring;

			updateStats(ring.getStrength(), ring.getDexterity(), ring.getConstitution(), ring.getIntelligence(), ring.getWisdom(), ring.getCharisma());
		}
	void CharacterClasses::Character::equipRing2(Ring ring)
		{
			this -> ring2 = ring;

			updateStats(ring.getStrength(), ring.getDexterity(), ring.getConstitution(), ring.getIntelligence(), ring.getWisdom(), ring.getCharisma());
		}
	void CharacterClasses::Character::equipWeapon(Weapon weapon)
		{
			this -> weapon = weapon;

			updateStats(weapon.getStrength(), weapon.getDexterity(), weapon.getConstitution(), weapon.getIntelligence(), weapon.getWisdom(), weapon.getCharisma());
		}
	void CharacterClasses::Character::equipShield(Shield shield)
		{
			this -> shield = shield;

			updateStats(shield.getStrength(), shield.getDexterity(), shield.getConstitution(), shield.getIntelligence(), shield.getWisdom(), shield.getCharisma());
		}
	void CharacterClasses::Character::equipArmor(Armor armor)
		{
			this -> armor = armor;

			updateStats(armor.getStrength(), armor.getDexterity(), armor.getConstitution(), armor.getIntelligence(), armor.getWisdom(), armor.getCharisma());
		}
	void CharacterClasses::Character::equipBelt(Belt belt)
		{
			this -> belt = belt;

			updateStats(belt.getStrength(), belt.getDexterity(), belt.getConstitution(), belt.getIntelligence(), belt.getWisdom(), belt.getCharisma());
		}
	void CharacterClasses::Character::equipBoots(Boots boots)
		{
			this -> boots = boots;

			updateStats(boots.getStrength(), boots.getDexterity(), boots.getConstitution(), boots.getIntelligence(), boots.getWisdom(), boots.getCharisma());
		}

	Helmet CharacterClasses::Character::unequipHelmet()
		{
			Helmet returnHelmet = helmet;

			updateStats(-helmet.getStrength(), -helmet.getDexterity(), -helmet.getConstitution(), -helmet.getIntelligence(), -helmet.getWisdom(), -helmet.getCharisma());

			this -> helmet = Helmet(0, 0, 0, 0, 0, 0);

			return returnHelmet;
		}
	Ring   CharacterClasses::Character::unequipRing1()
		{
			Ring returnRing = ring1;

			updateStats(-ring1.getStrength(), -ring1.getDexterity(), -ring1.getConstitution(), -ring1.getIntelligence(), -ring1.getWisdom(), -ring1.getCharisma());

			this -> ring1 = Ring(0, 0, 0, 0, 0, 0);

			return returnRing;
		}
	Ring   CharacterClasses::Character::unequipRing2()
		{
			Ring returnRing = ring2;

			updateStats(-ring2.getStrength(), -ring2.getDexterity(), -ring2.getConstitution(), -ring2.getIntelligence(), -ring2.getWisdom(), -ring2.getCharisma());

			this -> ring2 = Ring(0, 0, 0, 0, 0, 0);

			return returnRing;
		}
	Weapon CharacterClasses::Character::unequipWeapon()
		{
			Weapon returnWeapon = weapon;			

			updateStats(-weapon.getStrength(), -weapon.getDexterity(), -weapon.getConstitution(), -weapon.getIntelligence(), -weapon.getWisdom(), -weapon.getCharisma());

			this -> weapon = Weapon(0, 0, 0, 0, 0, 0);

			return returnWeapon;
		}
	Shield CharacterClasses::Character::unequipShield()
		{
			Shield returnShield = shield;

			updateStats(-shield.getStrength(), -shield.getDexterity(), -shield.getConstitution(), -shield.getIntelligence(), -shield.getWisdom(), -shield.getCharisma());

			this -> shield = Shield(0, 0, 0, 0, 0, 0);

			return returnShield;
		}
	Armor  CharacterClasses::Character::unequipArmor()
		{
			Armor returnArmor = armor;

			updateStats(-armor.getStrength(), -armor.getDexterity(), -armor.getConstitution(), -armor.getIntelligence(), -armor.getWisdom(), -armor.getCharisma());

			this -> armor = Armor(0, 0, 0, 0, 0, 0);

			return returnArmor;
		}
	Belt   CharacterClasses::Character::unequipBelt()
		{
			Belt returnBelt = belt;

			updateStats(-belt.getStrength(), -belt.getDexterity(), -belt.getConstitution(), -belt.getIntelligence(), -belt.getWisdom(), -belt.getCharisma());

			this -> belt = Belt(0, 0, 0, 0, 0, 0);

			return returnBelt;
		}
	Boots  CharacterClasses::Character::unequipBoots()
		{
			Boots returnBoots = boots;

			updateStats(-boots.getStrength(), -boots.getDexterity(), -boots.getConstitution(), -boots.getIntelligence(), -boots.getWisdom(), -boots.getCharisma());

			this -> boots = Boots(0, 0, 0, 0, 0, 0);

			return returnBoots;
		}

	void CharacterClasses::Character::updateStats(int str, int dex, int con, int intl, int wis, int cha)
		{
			this -> str += str;
			this -> dex += dex;
			this -> con += con;
			this -> intl += intl;
			this -> wis += wis;
			this -> cha += cha;

			notify(*this);
		}
	
	string CharacterClasses::Character::toString()
	{
		ostringstream out;

		out << "Level: " << this -> getLevel() << endl
			<< "Hit Points: " << this -> getHP() << endl
			<< "Strength: " << this -> getStrength() << endl
			<< "Dexterity: " << this -> getDexterity() << endl
			<< "Constitution: " << this -> getConstitution() << endl
			<< "Intelligence: " << this -> getIntelligence() << endl
			<< "Wisdom: " << this -> getWisdom() << endl
			<< "Charisma: " << this -> getCharisma() << endl << endl;

		return out.str();
	}


	
	CharacterClasses::Fighter::Fighter(string name) : CharacterClasses::Character(name)	{}

	CharacterClasses::Fighter::Fighter(string name, int hp, int level, int str, int dex, int con, int intl, int wis, int cha) : Character(name)
		{
			setHP(hp);
			setLevel(level);
			setStrength(str);
			setDexterity(dex);
			setConstitution(con);
			setIntelligence(intl);
			setWisdom(wis);
			setCharisma(cha);				
		}

	CharacterClasses::Fighter::Fighter(string name, int hp, int level, int str, int dex, int con, int intl, int wis, int cha,
		Helmet helmet, Armor armor, Weapon weapon, Shield shield, Ring ring1, Ring ring2, Belt belt, Boots boots) : Character(name)
		{			
			setHP(hp);
			setLevel(level);
			setStrength(str);
			setDexterity(dex);
			setConstitution(con);
			setIntelligence(intl);
			setWisdom(wis);
			setCharisma(cha);	
			
			equipHelmet(helmet);
			equipArmor(armor);
			equipWeapon(weapon);
			equipShield(shield);
			equipRing1(ring1);
			equipRing2(ring2);
			equipBelt(belt);
			equipBoots(boots);
		}

