#pragma once


#include <list>
#include <iostream>
#include <string>
#include "Observer.h"

using namespace std;

class Observable
{
	private:
		
		list<Observer*> observers;

	public:
		
		virtual ~Observable();

		void attach(Observer*);

		void detach(Observer*);
		
		void notify(Character&);
};