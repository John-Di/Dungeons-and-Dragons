#pragma once

#include "Console.h"
#include <iostream>

using namespace std;

Console::Console(){}

void Console::update(Character* c)
{
	Character character = *c;
	cout << character.toString();
}

