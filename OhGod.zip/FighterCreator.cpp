//ALL D20 RULES AND WHATNOT were taken from http://www.dandwiki.com/wiki/Main_Page and http://www.wikihow.com/Create-a-Dungeons-and-Dragons-Character
//http://boredoms4squares.com/2010/04/intro-to-dungeons-and-dragons-3-5-part-three/
//
//and http://www.d20srd.org/srd/classes/fighter.htm or more generally
//http://www.d20srd.org/

#pragma once
#include <iostream>
#include "d20.h"
#include "Items.h"
#include <stdio.h>
#include "CharacterClasses.h"
#include "Console.h"

using namespace std;
using namespace CharacterClasses;
using namespace Equipables;
using namespace d20;

int main()
{

	Console cs = Console();

	cout << "Welcome to the Dungeons and Dragons Fighter Class Creator!" << endl << endl
		 << "Let me introduce you to Level 1 Fighter - Gavin Free" << endl << endl;

	string name = "Gavin Free";
	
	int intelligence = Dice::roll4D6(),								//In order to avoid coupling, the fighter's creation was done here in the driver
		intModifier = Modifier::ability(intelligence),				//Instead of rolling values in the constructor of the fighter class
																	//Once other classes are introduced, there will be a character generator
																	//Helper class that will do all this for the game
	
		charisma =	    Dice::roll4D6() + (2 + intModifier) * 4,
		constitution =  Dice::roll4D6() + (2 + intModifier) * 4,
		dexterity =     Dice::roll4D6() + (2 + intModifier) * 4,
		strength = 	    Dice::roll4D6() + (2 + intModifier) * 4,
		wisdom =	    Dice::roll4D6() + (2 + intModifier) * 4,

		hp = Dice::roll(10) + Modifier::ability(constitution),
		level = 1;

	
		intelligence = intelligence + (2 + intModifier) * 4;
	

	CharacterClasses::Fighter gavin = 
		CharacterClasses::Fighter("Gavin Free", hp, level, strength, dexterity, constitution, intelligence, wisdom, charisma);

	gavin.attach(&cs);
	

	cout << "Let's get " << gavin.getName() << " started!" << endl << endl;
	cout << "Gavin is all set up! Let's see his stats!" << endl << endl;
	cout << gavin.toString();


	cout << "Let's give Gavin some Armor:" << endl;

	Armor gavins = Armor(10,2,3,4,5,6);

	cout << "Armor Strength: " << gavins.getStrength() << endl
		 << "Armor Dexterity: " << gavins.getDexterity() << endl
		 << "Armor Constitution: " << gavins.getConstitution() << endl
		 << "Armor Intelligence: " << gavins.getIntelligence() << endl
		 << "Armor Wisdom: " << gavins.getWisdom() << endl
		 << "Armor Charisma: " << gavins.getCharisma() << endl << endl;

	cout << "Gavin has some new Armor! Let's see his stats!" << endl << endl;
	gavin.equipArmor(gavins);

	cout << "This armor is too heavy for Gavin! Let's take it off!" << endl << endl;	
	gavin.unequipArmor();

	system("PAUSE");
	return 0;
}