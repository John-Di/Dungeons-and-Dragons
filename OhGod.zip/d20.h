#pragma once
#ifndef DICE_H
#define DICE_H

using namespace std;

namespace d20
{
	class Dice		//Used to generate random values for dice rolls
	{
		public:
			static int roll(int);

			static int roll4D6();
	};

	class Modifier
	{
		public:
			static int ability(int);
	};

}

#endif