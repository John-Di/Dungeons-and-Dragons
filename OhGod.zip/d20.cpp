#pragma once
#include "d20.h"
#include <stdlib.h> 
#include <algorithm>
#include <iostream>
#include <time.h> 
#include "SystemTimeDelay.h"


using namespace d20;
using namespace std;


int Dice::roll(int size) 
{
	delay(100);

	srand (time(NULL));
	int random =  rand() % size  + 1 ;
	return random;
}

int Dice::roll4D6()
{
	int rolls [4] = {roll(6), roll(6), roll(6), roll(6)};
	std::sort(std::begin(rolls), std::end(rolls));

	return rolls [1] + rolls [2] + rolls [3];
}

int Modifier::ability(int ability)
{
	return 	(ability - 10) / 2;		
}