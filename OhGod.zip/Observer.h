#pragma once


#include <iostream>
#include <string>
#include "CharacterClasses.h"

using namespace CharacterClasses;

class Observer
{
	public:		
		virtual void update(Character*) = 0;	
};