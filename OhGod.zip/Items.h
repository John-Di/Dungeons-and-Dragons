/*
All types of equipable items (ie Helmet, Armor, Weapons, Rings, Boots, Belts, Shield) are children of an Equipable interface.
The Equipable interface has yet to be properly made abstract because of a lack of need for a virtual method.
*/

#pragma once

using namespace std;

namespace Equipables
{
	class Equipable
	{
		public: 
			Equipable(int, int, int, int, int, int);

			int getStrength();
			int getDexterity();
			int getConstitution();
			int getIntelligence();
			int getWisdom();
			int getCharisma();

		private:
			int str, dex, con, intl, wis, cha;
	};

	class Helmet : public Equipable
	{
		public: 
			Helmet();
			Helmet(int, int, int, int, int, int);
	};

	class Armor : public Equipable
	{
		public: 
			Armor();
			Armor(int, int, int, int, int, int);
	};

	class Weapon : public Equipable
	{
		public: 
			Weapon();
			Weapon(int, int, int, int, int, int);
	};

	class Shield : public Equipable
	{
		public: 
			Shield();
			Shield(int, int, int, int, int, int);
	};
	
	class Ring : public Equipable
	{
		public: 
			Ring();
			Ring(int, int, int, int, int, int);
	};
	
	class Belt : public Equipable
	{
		public: 
			Belt();
			Belt(int, int, int, int, int, int);
	};
	
	class Boots : public Equipable
	{
		public: 
			Boots();
			Boots(int, int, int, int, int, int);
	};
}
