
#include "Observable.h"


Observable::~Observable()
{
	observers.clear();
}

void Observable::notify(Character& c)
{
	list<Observer*>::iterator it = observers.begin();

	Character* ch = &c;

	for(Observer* ob: observers)
	{
		ob -> update(ch);
	}
}

void Observable::attach(Observer* obs)
{
	observers.push_back(obs);
}

void Observable::detach(Observer* obs)
{
	observers.remove(obs);
}
