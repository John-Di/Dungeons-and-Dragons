#pragma once


#include <iostream>
#include <string>
#include "Observer.h"

using namespace std;

class Console : public Observer
{
	public:
		
		Console();

		void Observer::update(Character*);
};
