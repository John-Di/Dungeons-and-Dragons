#pragma once
#ifndef OBSERVER_H
#define OBSERVER_H
#ifndef OBSERVABLE_H
#define OBSERVABLE_H

#include <list>
#include <iostream>
#include <string>

using namespace std;

namespace ObserverPattern
{
	class Observer
	{
		public:
			
			virtual void update(string) = 0;	
	};
	
	class Observable
	{
		private:
			
			list<Observer*> observers;

		public:
			
			virtual ~Observable();

			void attach(Observer*);

			void detach(Observer*);
			
			void notify(string);
	};

}

#endif
#endif

