#pragma once
#include "Items.h"
using namespace Equipables;


Equipable::Equipable(int str, int dex, int con, int intl, int wis, int cha) : str(str), dex(dex), con(con), intl(intl), wis(wis), cha(cha){}

int Equipable::getStrength()
		{
			return str;
		}

int Equipable::getDexterity()
		{
			return dex;
		}

int Equipable::getConstitution()
		{
			return con;
		}

int Equipable::getIntelligence()
		{
			return intl;
		}

int Equipable::getWisdom()
		{
			return wis;
		}

int Equipable::getCharisma()
		{
			return cha;
		}


Helmet::Helmet() : Equipable(0,0,0,0,0,0){};
Helmet::Helmet(int str, int dex, int con, int intl, int wis, int cha) : Equipable(str, dex, con, intl, wis, cha){};

Armor::Armor() : Equipable(0,0,0,0,0,0){};
Armor::Armor(int str, int dex, int con, int intl, int wis, int cha) : Equipable(str, dex, con, intl, wis, cha){};
 
Weapon::Weapon() : Equipable(0,0,0,0,0,0){};
Weapon::Weapon(int str, int dex, int con, int intl, int wis, int cha) : Equipable(str, dex, con, intl, wis, cha){};

Shield::Shield() : Equipable(0,0,0,0,0,0){};
Shield::Shield(int str, int dex, int con, int intl, int wis, int cha) : Equipable(str, dex, con, intl, wis, cha){};

Ring::Ring() : Equipable(0,0,0,0,0,0){};
Ring::Ring(int str, int dex, int con, int intl, int wis, int cha) : Equipable(str, dex, con, intl, wis, cha){};

Belt::Belt() : Equipable(0,0,0,0,0,0){};
Belt::Belt(int str, int dex, int con, int intl, int wis, int cha) : Equipable(str, dex, con, intl, wis, cha){};
 
Boots::Boots() : Equipable(0,0,0,0,0,0){};
Boots::Boots(int str, int dex, int con, int intl, int wis, int cha) : Equipable(str, dex, con, intl, wis, cha){};
