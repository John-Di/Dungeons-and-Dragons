#pragma once
#include "Observers.h"
#include <iostream>

using namespace Observers;
using namespace std;

Console::Console(){}

void Console::update(string str)
{
	cout << str;
}

