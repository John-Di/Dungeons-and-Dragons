#pragma once
#include <iostream>
#include "CharacterClasses.h"

using namespace CharacterClasses;
//using namespace Equipables;
//using namespace std;
 


	int Character::checkLevelUp(int exp) 		//Checks to see if a character's exp passed the level up threshold
	{			
		int currentExp = this -> exp,
			level = this -> level, 
			nextLevelEXP;

		if(currentExp >= (nextLevelEXP = (level * (level + 1) * 500)))
		{				
			levelUp();

			return checkLevelUp(currentExp - nextLevelEXP);
		}

		return currentExp;
	}
	void Character::levelUp()
		{
			this -> level++;
		}		
	
	Character::Character(string name) : name(name){exp = 0;};

	int Character::getHP()
		{
			return hp;
		}
	int Character::getLevel()
		{
			return level;
		}
	int Character::getStrength()
		{
			return str;
		}
	int Character::getDexterity()
		{
			return dex;
		}
	int Character::getConstitution()
		{
			return con;
		}
	int Character::getIntelligence()
		{
			return intl;
		}
	int Character::getWisdom()
		{
			return wis;
		}
	int Character::getCharisma()
		{
			return cha;
		}
	int Character::getExperience()
		{
			return exp;
		}
	string Character::getName()
		{
			return this -> name;
		}
	
	void Character::setHP(int hp)
		{
			this -> hp = hp;
		}
	void Character::setLevel(int level)
		{
			this -> level = level;
		}
	void Character::setStrength(int str)
		{
			this -> str = str;
		}
	void Character::setDexterity(int dex)
		{
			this -> dex = dex;
		}
	void Character::setConstitution(int con)
		{
			this -> con = con;
		}
	void Character::setIntelligence(int intl)
		{
			this -> intl = intl;
		}
	void Character::setWisdom(int wis)
		{
			this -> wis = wis;
		}
	void Character::setCharisma(int cha)
		{
			this -> cha = cha;
		}
	void Character::gainExperience(int exp)					//After spending exp to level up (if level up is possible with amount of exp), 
		{														//the remaining amount of exp becomes the new value
			this -> exp = checkLevelUp(exp);			
		}
	void Character::setName(string name)
		{
			this -> name = name;
		}

	Helmet Character::getHelmet()
		{
			return helmet;
		}
	Ring Character::getRing1()
		{
			return ring1;
		}
	Ring Character::getRing2()
		{
			return ring2;
		}
	Weapon Character::getWeapon()
		{
			return weapon;
		}
	Shield Character::getShield()
		{
			return shield;
		}
	Armor Character::getArmor()
		{
			return armor;
		}
	Belt Character::getBelt()
		{
			return belt;
		}
	Boots Character::getBoots()
		{
			return boots;
		}

	void Character::equipHelmet(Helmet helmet)
		{
			this -> helmet = helmet;

			updateStats(helmet.getStrength(), helmet.getDexterity(), helmet.getConstitution(), helmet.getIntelligence(), helmet.getWisdom(), helmet.getCharisma());
		}
	void Character::equipRing1(Ring ring)
		{
			this -> ring1 = ring;

			updateStats(ring.getStrength(), ring.getDexterity(), ring.getConstitution(), ring.getIntelligence(), ring.getWisdom(), ring.getCharisma());
		}
	void Character::equipRing2(Ring ring)
		{
			this -> ring2 = ring;

			updateStats(ring.getStrength(), ring.getDexterity(), ring.getConstitution(), ring.getIntelligence(), ring.getWisdom(), ring.getCharisma());
		}
	void Character::equipWeapon(Weapon weapon)
		{
			this -> weapon = weapon;

			updateStats(weapon.getStrength(), weapon.getDexterity(), weapon.getConstitution(), weapon.getIntelligence(), weapon.getWisdom(), weapon.getCharisma());
		}
	void Character::equipShield(Shield shield)
		{
			this -> shield = shield;

			updateStats(shield.getStrength(), shield.getDexterity(), shield.getConstitution(), shield.getIntelligence(), shield.getWisdom(), shield.getCharisma());
		}
	void Character::equipArmor(Armor armor)
		{
			this -> armor = armor;

			updateStats(armor.getStrength(), armor.getDexterity(), armor.getConstitution(), armor.getIntelligence(), armor.getWisdom(), armor.getCharisma());
		}
	void Character::equipBelt(Belt belt)
		{
			this -> belt = belt;

			updateStats(belt.getStrength(), belt.getDexterity(), belt.getConstitution(), belt.getIntelligence(), belt.getWisdom(), belt.getCharisma());
		}
	void Character::equipBoots(Boots boots)
		{
			this -> boots = boots;

			updateStats(boots.getStrength(), boots.getDexterity(), boots.getConstitution(), boots.getIntelligence(), boots.getWisdom(), boots.getCharisma());
		}

	Helmet Character::unequipHelmet()
		{
			Helmet returnHelmet = helmet;

			updateStats(-helmet.getStrength(), -helmet.getDexterity(), -helmet.getConstitution(), -helmet.getIntelligence(), -helmet.getWisdom(), -helmet.getCharisma());

			this -> helmet = Helmet(0, 0, 0, 0, 0, 0);

			return returnHelmet;
		}
	Ring Character::unequipRing1()
		{
			Ring returnRing = ring1;

			updateStats(-ring1.getStrength(), -ring1.getDexterity(), -ring1.getConstitution(), -ring1.getIntelligence(), -ring1.getWisdom(), -ring1.getCharisma());

			this -> ring1 = Ring(0, 0, 0, 0, 0, 0);

			return returnRing;
		}
	Ring Character::unequipRing2()
		{
			Ring returnRing = ring2;

			updateStats(-ring2.getStrength(), -ring2.getDexterity(), -ring2.getConstitution(), -ring2.getIntelligence(), -ring2.getWisdom(), -ring2.getCharisma());

			this -> ring2 = Ring(0, 0, 0, 0, 0, 0);

			return returnRing;
		}
	Weapon Character::unequipWeapon()
		{
			Weapon returnWeapon = weapon;			

			updateStats(-weapon.getStrength(), -weapon.getDexterity(), -weapon.getConstitution(), -weapon.getIntelligence(), -weapon.getWisdom(), -weapon.getCharisma());

			this -> weapon = Weapon(0, 0, 0, 0, 0, 0);

			return returnWeapon;
		}
	Shield Character::unequipShield()
		{
			Shield returnShield = shield;

			updateStats(-shield.getStrength(), -shield.getDexterity(), -shield.getConstitution(), -shield.getIntelligence(), -shield.getWisdom(), -shield.getCharisma());

			this -> shield = Shield(0, 0, 0, 0, 0, 0);

			return returnShield;
		}
	Armor Character::unequipArmor()
		{
			Armor returnArmor = armor;

			updateStats(-armor.getStrength(), -armor.getDexterity(), -armor.getConstitution(), -armor.getIntelligence(), -armor.getWisdom(), -armor.getCharisma());

			this -> armor = Armor(0, 0, 0, 0, 0, 0);

			return returnArmor;
		}
	Belt Character::unequipBelt()
		{
			Belt returnBelt = belt;

			updateStats(-belt.getStrength(), -belt.getDexterity(), -belt.getConstitution(), -belt.getIntelligence(), -belt.getWisdom(), -belt.getCharisma());

			this -> belt = Belt(0, 0, 0, 0, 0, 0);

			return returnBelt;
		}
	Boots Character::unequipBoots()
		{
			Boots returnBoots = boots;

			updateStats(-boots.getStrength(), -boots.getDexterity(), -boots.getConstitution(), -boots.getIntelligence(), -boots.getWisdom(), -boots.getCharisma());

			this -> boots = Boots(0, 0, 0, 0, 0, 0);

			return returnBoots;
		}

	void Character::updateStats(int str, int dex, int con, int intl, int wis, int cha)
		{
			this -> str += str;
			this -> dex += dex;
			this -> con += con;
			this -> intl += intl;
			this -> wis += wis;
			this -> cha += cha;

			notify(this -> toString());
		}
	
	string Character::toString()
	{
		ostringstream out;

		out << "Level: " << this -> getLevel() << endl
			<< "Hit Points: " << this -> getHP() << endl
			<< "Strength: " << this -> getStrength() << endl
			<< "Dexterity: " << this -> getDexterity() << endl
			<< "Constitution: " << this -> getConstitution() << endl
			<< "Intelligence: " << this -> getIntelligence() << endl
			<< "Wisdom: " << this -> getWisdom() << endl
			<< "Charisma: " << this -> getCharisma() << endl << endl;

		return out.str();
	}


	
	Fighter::Fighter(string name) : Character(name)	{}

	Fighter::Fighter(string name, int hp, int level, int str, int dex, int con, int intl, int wis, int cha) : Character(name)
		{
			setHP(hp);
			setLevel(level);
			setStrength(str);
			setDexterity(dex);
			setConstitution(con);
			setIntelligence(intl);
			setWisdom(wis);
			setCharisma(cha);				
		}

	Fighter::Fighter(string name, int hp, int level, int str, int dex, int con, int intl, int wis, int cha,
		Helmet helmet, Armor armor, Weapon weapon, Shield shield, Ring ring1, Ring ring2, Belt belt, Boots boots) : Character(name)
		{			
			setHP(hp);
			setLevel(level);
			setStrength(str);
			setDexterity(dex);
			setConstitution(con);
			setIntelligence(intl);
			setWisdom(wis);
			setCharisma(cha);	
			
			equipHelmet(helmet);
			equipArmor(armor);
			equipWeapon(weapon);
			equipShield(shield);
			equipRing1(ring1);
			equipRing2(ring2);
			equipBelt(belt);
			equipBoots(boots);
		}

