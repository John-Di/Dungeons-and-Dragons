#pragma once
#ifndef CONSOLE_H
#define CONSOLE_H


#include "ObserverPattern.h"
#include <iostream>
#include <string>

using namespace std;

using namespace	ObserverPattern;

namespace Observers
{

	class Console : public Observer
	{
		public:
			
			Console();

			void Observer::update(string);
	};
}

#endif