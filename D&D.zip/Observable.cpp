#pragma once
#include "ObserverPattern.h"
#include <list>

using namespace ObserverPattern;

Observable::~Observable()
{
	observers.clear();
}

void Observable::notify(string str)
{
	list<Observer*>::iterator it = observers.begin();

	for(Observer* ob: observers)
	{
		ob -> update(str);
	}
}

void Observable::attach(Observer* obs)
{
	observers.push_back(obs);
}

void Observable::detach(Observer* obs)
{
	observers.remove(obs);
}

